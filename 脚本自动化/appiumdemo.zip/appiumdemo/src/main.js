const {remote} = require('webdriverio');
const fsPromises = require('fs').promises;
const path = require('path');
const { log } = require('console');

const capabilities = {
  'appium:platformName': 'Android',
  'appium:automationName': 'UiAutomator2',
  'appium:deviceName': 'emulator-5554',
  'appium:appPackage': 'com.tencent.mm',
  "appium:appActivity": "com.tencent.mm.ui.LauncherUI",
  "appium:automationName": "UiAutomator2",
  "appium:noReset":"true", // 是否重置
  "appium:fullReset":"false", //是否重置安装
  "appium:newCommandTimeout":"30000", //没有命令多少退出
};
// 定义一个基类
class WeTaskInfo {
  constructor(wid, status, message) {
    this.wid = wid;
    this.status = status; // 新增的status属性
    this.message = message; // 新增的message属性
  }
}
const wdOpts = {
  hostname: '127.0.0.1',
  path:"/wd/hub",
  port: 4723,
  logLevel: 'info',
  capabilities,
};

var  wids = []
function formatDate(date, format = 'yyyy-MM-dd HH:mm:ss') {
  const map = {
      'yyyy': date.getFullYear(),
      'MM': String(date.getMonth() + 1).padStart(2, '0'),
      'dd': String(date.getDate()).padStart(2, '0'),
      'HH': String(date.getHours()).padStart(2, '0'),
      'mm': String(date.getMinutes()).padStart(2, '0'),
      'ss': String(date.getSeconds()).padStart(2, '0')
  };

  return format.replace(/yyyy|MM|dd|HH|mm|ss/g, match => map[match]);
}
async function  loadWidData() {
    try {
      const filepath = path.join(__dirname, 'testwx.txt');
      const data = await fsPromises.readFile(filepath, 'utf8');
      console.log('data', data);
      const originalWids = data.split('\n');
      originalWids.forEach(item => {
          wids.push(new WeTaskInfo(item, 0, ""));
      });
      return wids;
    } catch (error) {
      console.log('errorxxx',error)
    }
    return [];
     
}
async function dealFinish() {
  let resultText = '';
  // 遍历wids数组，根据status属性统计并记录每个任务的状态
  wids.forEach(wxtask => {
      let statusText = '';
      switch (wxtask.status) {
          case 0:
              statusText = '未添加';
              break;
          case 1:
              statusText = '添加成功';
              break;
          case -1:
              statusText = '添加异常';
              break;
          default:
              statusText = '未知状态';
      }
      resultText += `${wxtask.wid} ${statusText} ${wxtask.message}\n`;
  });

  // 添加统计总结
  const summary = `${formatDate(new Date())}本次统计结果\n未添加的任务数: ${wids.filter(task => task.status === 0).length}\n添加成功的任务数: ${wids.filter(task => task.status === 1).length}\n出现异常的任务数: ${wids.filter(task => task.status === -1).length}`;
  resultText += summary;
  try {
    const filepath = path.join(__dirname, 'taskresult.txt');
    // 将统计结果写入到taskresult.txt文件
    await fsPromises.appendFile(filepath, resultText);
  }catch(err){
    console.log('写入文件发生错误',err)
  }

} 
var driver = null;
async function runMain(){
  log('info','运行开始')
   try {
        wids =  await loadWidData()
        if(wids.length === 0){
          log('error','请先准备好数据')
          return;
        }
        driver = await remote(wdOpts);
        for (let i = 0; i < wids.length; i++) {
              const wxtask = wids[i];
              await runScriptMain(driver,wxtask)
        }
        await dealFinish();
   } catch (error) {
      console.log('error',error)
   }
   log('info','运行结束')

}
async function runScriptMain(driver,wxtask) {
  console.log(`开始添加好友${wxtask.wid}`)
  try{
    await driver.pause(1000);
    const searchAdd = await driver.$('android=new UiSelector().resourceId("com.tencent.mm:id/jga")');
    await searchAdd.click();
    await driver.pause(1000);
    await driver.back();
    // const addfriend = await driver.$('android=new UiSelector().resourceId("com.tencent.mm:id/m7g").instance(1)');
    // await addfriend.click();
    // await driver.pause(1000);
    // const search = await driver.$('android=new UiSelector().resourceId("com.tencent.mm:id/mmz")');
    // await search.click();
    // await driver.pause(1000);
    // const searchText = await driver.$('android=new UiSelector().resourceId("com.tencent.mm:id/d98")');
    // await searchText.setValue(wxtask.wid);
    // await driver.pause(1000);
    // const searchButton = await driver.$('android=new UiSelector().resourceId("com.tencent.mm:id/o_q")');
    // await searchButton.click();
    // await driver.pause(1000);
    // await driver.pause();
    wxtask.status = 1 
    wxtask.message = "加好友成功 待验证"
    await driver.pause(1000);
  }catch(error){
    console.log('error',error)
    wxtask.status = -1
    wxtask.message = "error"
  }
}

runMain().catch(log('error'));